#!/bin/bash

# Mostrar ayuda si el usuario pide -help
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Validar que se pasaron dos argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Debes indicar origen y destino"
    echo "Usá -help para ver el formato correcto"
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_"$FECHA".tar.gz

# Verificar que origen y destino existen y están montados
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen no existe"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: El directorio de destino no está montado"
    exit 1
fi

# Realizar el backup
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"

echo "Backup creado: $DESTINO/$NOMBRE"
